export interface ClassNameList {
    [key: string]: string;
}
export declare const CLASS_NAMES: ClassNameList;
export default CLASS_NAMES;
